<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Controle de Estoque dos Tesouros</title>
    <link rel="stylesheet" href="../estilos.css">
    <link rel="icon" href="../calice.ico">
  </head>
  <body>
