<?php
require("header.php");
require("config_auenticado.php");
require("footer.php");
?>
<form method="post" name="tesouroNovo" enctype="multipart/form-data">
Nome: <input type="text" name="nome" required><br>
Quantidade: <input type="text" name="quantidade" min="1" required><br>
valorUnitario: <input type="text" name="valorUnitario" min="0" required><br>
Icone: <input type="image" name="icone" required><br>
Id: <input type="hidden" name="id" required><br>
<button type="submit">Enviar</button>
</form>

<form method="post" name="tesouroAtualizado" enctype="multipart/form-data">
Nome: <input type="text" name="nome" required><br>
Quantidade: <input type="text" name="quantidade" min="1" required><br>
valorUnitario: <input type="text" name="valorUnitario" min="0" required><br>
Icone: <input type="null" name="icone"><br>
Id: <input type="hidden" name="id" required><br>
<button type="submit">Atualizar</button>
</form>

<?
$tesouro=null;
if(isset($_GET["id"])){
    $tesouro = Tesouro::getTesouroPorId();
}
?>
<input type="text" value="<?=$tesouro!=null?$tesouro->getNome():""?>">
<input type="text" value="<?=$tesouro!=null?$tesouro->getQuantidade():""?>">
<input type="text" value="<?=$tesouro!=null?$tesouro->getValorUnitario():""?>">
<input type="text" value="<?=$tesouro!=null?$tesouro->getId():""?>">






<?
if(isset($POST["tesouroNovo"]) || isset($POST["tesouroAtualizado"])){
  if(salvaDados($db,$dados,$_FILES)== true){
    require_once("piratas.php");
  }
}
?>
